import { AggregateRoot } from "../shared/aggregate-root.js";
import { UserId } from "./value-objects/user-id.vo.js";
import { Email } from "./value-objects/email.vo.js";
import { FullName } from "./value-objects/full-name.vo.js";
import { HashedPassword } from "./value-objects/hashed-password.vo.js";
import { UserCreatedEvent } from "./events/user-created.event.js";
import type { IdGeneratorPort, SystemClockPort } from "@nexus/shared";

export type UserStatus = "PENDING_VERIFICATION" | "ACTIVE" | "SUSPENDED";

interface UserProps {
  email: Email;
  fullName: FullName;
  hashedPassword: HashedPassword;
  status: UserStatus;
  createdAt: Date;
}

/**
 * User — the aggregate root for the identity bounded context.
 *
 * All invariants for "what makes a valid User" live here and ONLY here:
 * application services orchestrate, but never mutate the aggregate's
 * internals directly. Construction goes through the static factory
 * `User.register`, which is the single choke point that guarantees a User
 * can never exist in an invalid state and always raises `UserCreatedEvent`
 * as a first-class fact of the domain.
 */
export class User extends AggregateRoot<UserId> {
  private props: UserProps;

  private constructor(id: UserId, props: UserProps) {
    super(id);
    this.props = props;
  }
  

  /**
   * Factory for brand-new users. `hashedPassword` MUST already be hashed —
   * the aggregate refuses to know about hashing algorithms; that is an
   * infrastructure concern injected via the application layer's
   * PasswordHasher port.
   */
  public static register(
    params: {
      id: string;
      email: string;
      fullName: string;
      hashedPassword: string;
    },
    deps: { idGenerator: IdGeneratorPort; clock: SystemClockPort; traceId?: string | undefined },
  ): User {
    const userId = UserId.create(params.id);
    const email = Email.create(params.email);
    const fullName = FullName.create(params.fullName);
    const hashedPassword = HashedPassword.fromHash(params.hashedPassword);
    const createdAt = deps.clock.now();

    const user = new User(userId, {
      email,
      fullName,
      hashedPassword,
      status: "PENDING_VERIFICATION",
      createdAt,
    });

    user.addDomainEvent(
      new UserCreatedEvent(
        userId.value,
        { userId: userId.value, email: email.value, fullName: fullName.value },
        deps.idGenerator,
        deps.clock,
        deps.traceId,
      ),
    );

    return user;
  }

  /** Rehydration from persistence — no events raised, no re-validation of business rules that already held at write time. */
  public static reconstitute(id: UserId, props: UserProps): User {
    return new User(id, props);
  }

  public get email(): Email {
    return this.props.email;
  }

  public get fullName(): FullName {
    return this.props.fullName;
  }

  public get hashedPassword(): HashedPassword {
    return this.props.hashedPassword;
  }

  public get status(): UserStatus {
    return this.props.status;
  }

  public get createdAt(): Date {
    return this.props.createdAt;
  }

  public toPrimitives() {
    return {
      id: this.id.value,
      email: this.email.value,
      fullName: this.fullName.value,
      status: this.status,
      createdAt: this.createdAt,
    };
  }
}
