/**
 * Base Value Object: structural equality, immutability, self-validation.
 * Value objects never expose setters — a "change" produces a new instance.
 */
export abstract class ValueObject<Props extends object> {
  protected readonly props: Readonly<Props>;

  protected constructor(props: Props) {
    this.props = Object.freeze({ ...props });
  }

  public equals(other?: ValueObject<Props>): boolean {
    if (other === null || other === undefined) return false;
    return JSON.stringify(this.props) === JSON.stringify(other.props);
  }
}
