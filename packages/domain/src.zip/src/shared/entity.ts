/**
 * Base Entity: identity-based equality. Two entities are equal iff their
 * identifiers are equal, regardless of attribute values.
 */
export abstract class Entity<IdType> {
  protected readonly _id: IdType;

  protected constructor(id: IdType) {
    this._id = id;
  }

  public get id(): IdType {
    return this._id;
  }

  public equals(other?: Entity<IdType>): boolean {
    if (other === null || other === undefined) return false;
    if (this === other) return true;
    if (!(other instanceof Entity)) return false;
    return JSON.stringify(this._id) === JSON.stringify(other._id);
  }
}
