// packages/domain/src/events/domain-event-names.ts
export const DomainEventNames = {
    USER_CREATED: "user.created",
    USER_VERIFIED: "user.verified",
} as const;

export type DomainEventName = (typeof DomainEventNames)[keyof typeof DomainEventNames];