globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/JckE0gteSsQdqhgbKhaPB/_buildManifest.js",
    "static/JckE0gteSsQdqhgbKhaPB/_ssgManifest.js",
    "static/JckE0gteSsQdqhgbKhaPB/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3l04zcqx63h3y.js",
    "static/chunks/0ay527mnq1105.js",
    "static/chunks/0bma92pht_c97.js",
    "static/chunks/3j_ytfcvdhu3y.js",
    "static/chunks/turbopack-3bo8m1m4tck2k.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
