import path from "node:path";
import { fileURLToPath } from "node:url";

import dotenv from "dotenv";
import { z } from "zod";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// dotenv.config({ path: path.resolve(__dirname, "../../../../.env") });
dotenv.config({ path: path.resolve(process.cwd(), ".env") });

const EnvSchema = z.object({ 
KAFKA_BROKER: z.string().default("127.0.0.1:9092"),
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
DATABASE_URL: z.string().default("postgres://nexus:nexus@localhost:5432/nexus_users")
});

export type Env = z.infer<typeof EnvSchema>;

/**
 * Fail fast: an invalid/missing environment variable crashes the process
 * at boot with a precise error, rather than surfacing as a confusing
 * runtime failure three layers deep once a request finally touches it.
 */
export function loadEnv(): Env {
  const parsed = EnvSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error("Invalid environment configuration:", parsed.error.flatten().fieldErrors);
    process.exit(1);
  }
  return parsed.data;
}
