import OpenAPIHandler from "@graphql-mesh/openapi";
import { MeshStore, InMemoryStoreStorageAdapter } from "@graphql-mesh/store";
import type { FastifyInstance } from "fastify";
import fp from "fastify-plugin";
import mercurius from "mercurius";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";


export const graphqlMeshPlugin = fp(
  async (app: FastifyInstance) => {
    console.log("--------------------------------------------------");
    console.log("🔍 [STEP 1] Registering Mercurius default schema...");

    await app.register(mercurius, {
      schema: `type Query { _health: String }`,
      path: "/graphql",
      graphiql: false,
      context: (request) => ({ headers: request.headers }),
    });

    app.addHook("onReady", async () => {
      console.log("🔍 [STEP 2] Fastify onReady hook triggered.");

      try {
        console.log("🔍 [STEP 3] Fetching Swagger JSON via app.swagger()...");
        const rawSwagger = app.swagger();

        if (!rawSwagger) {
          console.log("❌ [STEP 3.1] app.swagger() returned falsy value!");
          return;
        }

        const openapiSpec = JSON.parse(JSON.stringify(rawSwagger));
        const pathsCount = Object.keys(openapiSpec.paths || {}).length;
        console.log(`🔍 [STEP 3.2] Swagger Spec captured. Found ${pathsCount} paths in spec.`);

        console.log("🔍 [STEP 4] Initializing MeshStore...");
        const dummyStore = new MeshStore(
          "NexusApiStore",
          new InMemoryStoreStorageAdapter(),
          { readonly: false, validate: false }
        );
        console.log("🔍 [STEP 4.1] MeshStore created successfully.");

        console.log("🔍 [STEP 5] Instantiating OpenAPIHandler...");
      // root filesystem در k8s فقط‌خواندنی است؛ فقط /tmp (emptyDir) قابل نوشتن است
      const tmpSpecPath = path.join(os.tmpdir(), "temp-openapi.json");
fs.writeFileSync(tmpSpecPath, JSON.stringify(openapiSpec, null, 2));

const customLogger = {
  debug: (...args: any[]) => console.log("🐛 [MESH DEBUG]:", ...args),
  info: (...args: any[]) => console.log("ℹ️ [MESH INFO]:", ...args),
  warn: (...args: any[]) => console.warn("⚠️ [MESH WARN]:", ...args),
  error: (...args: any[]) => console.error("❌ [MESH ERROR]:", ...args),
  child: () => customLogger, // 👈 اضافه کردن متد child برای جلوگیری از کرش omnigraph
};

const handler = new OpenAPIHandler({
  name: "NexusApi",
  store: dummyStore,
  config: {
    source: tmpSpecPath,
    endpoint: process.env["API_PUBLIC_URL"] ?? "http://localhost:3000",
    fillMissingResponses: true,
  },
  baseDir: process.cwd(),
  importFn: (m: string) => import(m),
  logger: customLogger as any,
} as any);
        console.log("🔍 [STEP 5.1] OpenAPIHandler instance ready.");

        console.log("🔍 [STEP 6] Calling handler.getMeshSource()...");
        const meshSource = await handler.getMeshSource({
          fetchFn: globalThis.fetch,
        } as any);

        console.log("🔍 [STEP 6.1] getMeshSource evaluation:", {
          hasMeshSource: !!meshSource,
          hasSchema: !!meshSource?.schema,
        });

        const schema = meshSource?.schema;

        if (!schema) {
          console.log("❌ [STEP 6.2] Mesh returned NULL or UNDEFINED schema!");
          return;
        }

        console.log("🔍 [STEP 7] Checking app.graphql instance...");
        if (app.graphql) {
          console.log("🔍 [STEP 7.1] Replacing Mercurius schema with Mesh schema...");
          app.graphql.replaceSchema(schema);

          console.log("🚀 [SUCCESS] Enterprise GraphQL Engine schema replaced successfully!");
        } else {
          console.log("❌ [STEP 7.3] app.graphql is undefined! Cannot replace schema.");
        }
        console.log("--------------------------------------------------");

      } catch (err) {
        console.error("❌ [CRITICAL EXCEPTION] Error during Mesh init:", err);
        console.log("--------------------------------------------------");
      }
    });
  },
  { name: "graphql-mesh-plugin" }
);