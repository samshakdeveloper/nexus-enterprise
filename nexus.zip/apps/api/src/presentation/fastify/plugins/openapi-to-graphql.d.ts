declare module "openapi-to-graphql" {
  export interface Options {
    strict?: boolean;
    fillEmptyResponses?: boolean;
    viewer?: boolean;
    baseUrl?: string;
    [key: string]: any;
  }

  export function openapiToGraphql(
    openapiObject: any,
    options?: Options
  ): Promise<{ schema: any; report: any }>;
}